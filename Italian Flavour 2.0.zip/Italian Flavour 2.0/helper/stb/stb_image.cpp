#define STB_IMAGE_IMPLEMENTATION
// #include "helper/stb/stb_image.h"	// stupid piece of shit cannot recognize
#include "stb_image.h"